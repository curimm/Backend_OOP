﻿// c++HW.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"
#include <iostream>
#include <conio.h>
#include <time.h>

using namespace std;

/*
enum class CellType
{
   Mine,
   Brick
};

class Cell
{
private :
   CellType cellType;
   bool undiscovered;

   char shape;

   void setCellShape()
   {
	  switch (cellType)
	  {
		 case CellType::Mine:
		 {
			shape = '*';
		 }
		 break;
		 case CellType::Brick:
		 {
			shape = 'O';
		 }
		 break;
		 default:
		 {
			shape = '_';
		 }
		 break;
	  }
   }

public :
   Cell(const CellType&cellType = CellType::Brick)
	  : cellType(cellType), undiscovered(true), shape(NULL)
   {
	  setCellShape();
   }

};
*/


//벽: O / 지뢰: * / 셀: !
class MineMap
{
public:

	static const char BrickShape = 'O';
	static const char MineShape = '*';
	static const char FoundCellShape = '!';

private:

	int mapRow;
	int mapColumn;
	int offset;

	char * map;

	// mapRow * mapColumn
	int totalSize;


	bool checkSize() const
	{
		return (mapRow > 0 && mapColumn > 0);
	}

	bool checkIndex(int index) const
	{
		return (0 <= index && totalSize > index);
	}

	bool checkRange(int x, int y) const
	{
		if (0 > x || 0 > y)
			return false;
		if (mapRow <= x || mapColumn <= y)
			return false;

		return true;
	}

	bool checkIsMine(int x, int y) const
	{
		// 만약 범위 바깥이면 지뢰가 아니다.
		if (false == checkRange(x, y))
			return false;

		return (map[x + y * mapRow] == MineShape);
	}

	bool setPoint(int x, int y, char shape)
	{
		if (false == checkRange(x, y))
			return false;
		if (false == checkSize())
			return false;

		map[x + y * mapRow] = shape;
		return true;
	}

	bool setPoint(int index, char shape)
	{
		if (false == checkIndex(index))
			return false;
		if (false == checkSize())
			return false;

		map[index] = shape;
		return true;
	}

	void removeBrick(int x, int y)
	{
		if (false == checkRange(x, y))
			return;
		map[x + y * mapRow] = FoundCellShape;
	}

	bool checkAdjacentCellsAreBrick(int x, int y) const
	{

		// 인접한 셀들 중에 지뢰 존재하면 false, 없으면 true반환
		if (true == checkIsMine(x + 1, y) ||
			true == checkIsMine(x, y + 1) ||
			true == checkIsMine(x - 1, y) ||
			true == checkIsMine(x, y - 1) ||
			true == checkIsMine(x + 1, y + 1) ||
			true == checkIsMine(x - 1, y - 1) ||
			true == checkIsMine(x + 1, y - 1) ||
			true == checkIsMine(x - 1, y + 1)
			)
		{
			return false;
		}

		return true;

	}

	void resetMap()
	{
		if (false == checkSize())
			return;

		if (nullptr == map)
			return;

		// 모두 벽돌로 초기화
		for (int i = 0; i < totalSize; ++i)
		{
			map[i] = BrickShape;
		}
		// 마지막 널문자
		map[totalSize] = '\0';
	}

	void landMineRandomly()
	{
		if (false == checkSize())
			return;

		// 1/2 확률로 지뢰로 바꿔줌.
		bool landMineFlag;
		for (int i = 0; i < totalSize; ++i)
		{
			landMineFlag = (bool)(rand() % 5);

			if (false == landMineFlag)
			{
				setPoint(i, '*');
			}
		}

	}

public:
	MineMap(int mapRow, int mapColumn, int offset)
		: mapRow(mapRow), mapColumn(mapColumn), offset(offset), map(nullptr), totalSize(mapRow*mapColumn)
	{
		srand(unsigned int(time(0)));
		generateMapWithMines();
	}

	virtual ~MineMap()
	{
		delete[] map;
	}


	void generateMapWithMines()
	{
		if (false == checkSize())
			return;

		// 널 문자 포함해서 만들어 준다.
		map = new char[totalSize + 1];

		// 맵을 모두 벽돌로 바꿔주고
		resetMap();

		// 1/2확률로 지뢰를 설치한다.
		landMineRandomly();
	}

	void render() const
	{
		if (false == checkSize())
			return;


		// 한줄씩 출력한다.
		for (int i = 0; i < mapColumn; ++i)
		{
			printf("%.*s\n", mapRow, map + (mapRow*i));
		}

	}

	bool removeIfAdjacentCellsAreNotMine(int x, int y)
	{
		// 범위안의 xy값이 아니면 false리턴
		if (false == checkRange(x, y))
			return false;

		// 먼저 여기가 지뢰인지 체크 지뢰면 지우지 못하기 때문에 false리턴한다.
		if (true == checkIsMine(x, y))
			return false;

		// 주위의 셀이 하나라도 지뢰가 있는지 체크
		// if문 시작
		if (true == checkAdjacentCellsAreBrick(x, y))
		{
			// 만약 지뢰가 없다면 모두 지워주고 지워진 셀에 대해서도 removeIfAdjacentCellsAreNotMine를 재귀적으로 호출한다.
			// 인접셀에 접근하는 루프
			for (int offsetX = -1; offsetX < 2; ++offsetX)
			{
				for (int offsetY = -1; offsetY < 2; ++offsetY)
				{
					if (checkRange(x + offsetX, y + offsetY))
					{
						removeBrick(x + offsetX, y + offsetY);
						// 다시 재귀적으로 호출
						removeIfAdjacentCellsAreNotMine(x + offsetX, y + offsetY);
					}
				}
			}
		}
		// if문 끝

	}
};

int main()
{
	char input = '\0';
	MineMap mineMap(20, 20, 3);
	//mineMap.removeAllBricks();
	while (false == (input == '1'))
	{
		if (_kbhit())
		{
			input = _getch();
		}

		system("cls");

		mineMap.render();

	}

	return 0;
}